/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author Student
 */


import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {
            Login login = new Login();
            
            // First name
            System.out.print("Enter First Name: ");
            String firstName = scanner.nextLine();
            
            // Last name
            System.out.print("Enter Last Name: ");
            String lastName = scanner.nextLine();
            
            // Username
            String username;
            
            while (true) {
                
                System.out.print("Enter Username (must contain '_' and <=5 chars): ");
                username = scanner.nextLine();
                
                System.out.println(login.getUsernameStatus(username));
                
                if (login.checkUserName(username)) {
                    break;
                }
            }
            
            // Password
            String password;
            
            while (true) {
                
                System.out.print("Enter Password (8 chars, capital, number, special): ");
                password = scanner.nextLine();
                
                System.out.println(login.getPasswordStatus(password));
                
                if (login.checkPasswordComplexity(password)) {
                    break;
                }
            }
            
            // Cellphone number
            String cell;
            
            while (true) {
                
                System.out.print("Enter Cell (e.g. +27838968976): ");
                cell = scanner.nextLine();
                
                System.out.println(login.getCellStatus(cell));
                
                if (login.checkCellPhoneNumber(cell)) {
                    break;
                }
            }
            
            // Register the user
            System.out.println(login.registerUser(username, password, cell));
            
            // Store the user's details
            login.setStoredCredentials(
                    username,
                    password,
                    cell,
                    firstName,
                    lastName
            );
            
            // Login
            System.out.println("\n=== LOGIN ===");
            
            System.out.print("Enter Username: ");
            String enteredUsername = scanner.nextLine();
            
            System.out.print("Enter Password: ");
            String enteredPassword = scanner.nextLine();
            
            System.out.println(
                    login.returnLoginStatus(
                            enteredUsername,
                            enteredPassword
                    )
            );
        }
    }
}

