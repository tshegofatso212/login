/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package com.mycompany.login;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login login = new Login();

    @Test
    public void testUsernameCorrectlyFormatted_ReturnsTrue() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted_ReturnsFalse() {
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testPasswordMeetsComplexity_ReturnsTrue() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexity_ReturnsFalse() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneCorrectlyFormatted_ReturnsTrue() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted_ReturnsFalse() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testUsernameCorrectlyFormatted_AssertEquals() {
        assertEquals(
            "Username successfully captured.",
            login.getUsernameStatus("kyl_1")
        );
    }

    @Test
    public void testUsernameIncorrectlyFormatted_AssertEquals() {
        assertEquals(
            "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.",
            login.getUsernameStatus("kyle!!!!!!!")
        );
    }

    @Test
    public void testPasswordMeetsComplexity_AssertEquals() {
        assertEquals(
            "Password successfully captured.",
            login.getPasswordStatus("Ch&&sec@ke99!")
        );
    }

    @Test
    public void testPasswordDoesNotMeetComplexity_AssertEquals() {
        assertEquals(
            "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
            login.getPasswordStatus("password")
        );
    }

    @Test
    public void testCellCorrectlyFormatted_AssertEquals() {
        assertEquals(
            "Cell number successfully captured.",
            login.getCellStatusAlt("+27838968976")
        );
    }

    @Test
    public void testCellIncorrectlyFormatted_AssertEquals() {
        assertEquals(
            "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
            login.getCellStatusAlt("08966553")
        );
    }

    @Test
    public void testLoginSuccessful_ReturnsTrue() {
        login.setStoredCredentials(
            "kyl_1",
            "Ch&&sec@ke99!",
            "+27838968976",
            "Kyle",
            "Smith"
        );

        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed_ReturnsFalse() {
        login.setStoredCredentials(
            "kyl_1",
            "Ch&&sec@ke99!",
            "+27838968976",
            "Kyle",
            "Smith"
        );

        assertFalse(login.loginUser("kyl_1", "wrongPass123!"));
    }
}
